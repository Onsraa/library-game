#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "./functions/functions.h"
#include "./scenarios/scenarios.h"

int main(){

Library * library = NULL;

startGame(library);

/*
Library * myLib = initialisation();
addBook(myLib);
addBook(myLib);
addBook(myLib);

char sentence[20];
fgets(sentence, sizeof(sentence), stdin);
int count = 0;

while(sentence[count] != '\0'){
    if(sentence[count] == '\n'){
        sentence[count] = '\0';
    }
    count++;
}


//printf("Book : ");
addWord(myLib->first_book, sentence);
//addWord(myLib->first_book, sentence);
//addWord(myLib->first_book, "haha hihi \nhaha");
showBook(myLib->first_book);
//showLibrary(myLib);
*/
exit(EXIT_SUCCESS);
}
