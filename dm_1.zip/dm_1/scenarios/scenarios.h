//Scenario
void startGame(Library * library);
void menu(Library * library);

//Menu
//*1
void enterLibrary(Library * library);
//*2
void addBookMenu(Library * library);